package Data_Structures;

public class Binary_Tree {
	Node root;
	
	public Binary_Tree(Node root) {
		this.root = root;
	}
	public void Connect(Node node, Node inspect) {
		if(!isFather(inspect)) {
			Node temp = new Node(node.GetData());
			temp.SetRight(node.GetRight());
			temp.SetLeft(node.GetLeft());
			if(node.GetData() >= inspect.GetData()) {
				inspect.SetRight(temp);
			}
			else {
				inspect.SetLeft(temp);
			}
		}
		else {
			if(node.GetData() >= inspect.GetData()) {
				Connect(node, inspect.GetRight());
			}
			else {
				Connect(node, inspect.GetLeft());
			}
		}
	}
	public boolean isFather(Node s) {
		if(s.GetLeft() == null && s.GetLeft() == null) {return false;}
		return true;
	}
	public boolean ContainsPreorder(Node n, int data) {
		if(n.equals(null)) return false;
		return (n.GetData() == data || ContainsPreorder(n.GetLeft(), data) || ContainsPreorder(n.GetRight(), data) );
	}
	public boolean ContainsInorder(Node n, int data) {
		if(n.equals(null))return false;
		if(n.GetData() == data) return true;
		else if(n.GetData() <= data) {
			return ContainsInorder(n.GetRight(), data);
		}
		else {
			return ContainsInorder(n.GetLeft(), data);
		}
	}
	
}
